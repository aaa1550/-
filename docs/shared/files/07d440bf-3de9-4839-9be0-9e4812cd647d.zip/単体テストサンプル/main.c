/* インクルード ***********************************************************/
#include "lpc13xx.h"
#include "gpio.h"
#include "vs-wrc103.h"
#include "type.h"

/* グローバル変数 *******************************************************/
unsigned char ucg_ONOFF = 0; 

/* 固定値定義 **********************************************************/
#define	USL_AD_THRESHOLD	500
#define UCL_MOVE_STOP		0
#define UCL_MOVE_STRAIGHT	1
#define UCL_MOVE_LEFT		2
#define UCL_MOVE_RIGHT		3
#define UCL_OFF			0
#define UCL_ON			1
#define UCL_SW_OFF		0
#define UCL_SW_ON		1


void main()
{
	unsigned short	usl_ADleft;
	unsigned short	usl_ADright;
	unsigned char	ucl_rtn;
	
	// SW ON→OFF待ち
	// ※ 単体テスト時は、4ループ目でON、5ループ目でOFFするようにテストする。
	while(gwtSW() == OFF){
		// SW ONまで無限ループで待機
	}
	whlle(gwtSW() == ON){
		// SW OFFまで無限ループで待機
	}
	
	if(ucg_ONOFF = UCG_ON){

		usl_ADleft	= ADread(0);
		usl_ADright	= ADread(1);

		if(usl_ADleft	>  USL_AD_THRESHOLD &&
 		   usl_ADright	<= USL_AD_THRESHOLD){
			ucl_rtn = UCL_MOVE_LEFT;

		}else if{(usl_ADleft	<= USL_AD_THRESHOLD &&
 		    	  usl_ADright	>  USL_AD_THRESHOLD){
			  ucl_rtn = UCL_MOVE_RIGHT;
	
		else
			  ucl_rtn = UCL_MOVE_STRAIGHT;
		}
	}else{
		ucl_rtn = UCL_MOVE_STOP;
	}

}
