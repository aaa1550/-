#include <stdio.h>

// スタブ関数の確認用変数宣言
unsigned char 	AMSTB_ADread_arg[2] 	= {0, 0};
unsigned short	AMSTB_ADread_rtn[2] 	= {0, 0};
unsigned char 	AMSTB_ADread_call 	= 0;

// スタブ関数本体
unsigned short AMSTB_ADread(unsigned char ch){

    	unsigned short ucl_rtn;

    	ucl_rtn = AMSTB_ADread_rtn[AMSTB_ucmTest_Call];		// 戻り値をローカル変数へ退避
    	AMSTB_ADread_arg[AMSTB_ADread_call] = ch;		// 引数の確認用
    	AMSTB_ADread_call++;					// コール回数の確認用

	return(ucl_rtn);					// 戻り値の確認用
}

// スタブ関数の確認用変数宣言
unsigned short	AMSTB_getSW_rtn[5] 	= {0, 0, 0, 0, 0};	//無限ループに使用されるため、
unsigned char 	AMSTB_getSW_call 	= 0;			//5回だけコールされる想定

// スタブ関数本体
unsigned char AMSTB_getSW(){
	
    	unsigned short ucl_rtn;

    	ucl_rtn = AMSTB_getSW_rtn[AMSTB_getSW_call];		// 戻り値をローカル変数へ退避
	AMSTB_getSW_call++;					// コール回数の確認用

	return(ucl_rtn);	

}