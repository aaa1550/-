#include <Arduino.h>
#include <IRremote.hpp>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <algorithm>
uint32_t fakeNow=1000;
uint32_t fakePulseAdvance=0;
int pins[32],pwm[32],modes[32];
int reads=0,writes=0,analogCalls=0,modeCalls=0,pulseCalls=0,delayCalls=0;
int pulsePin=-1,pulseLevel=-1;
unsigned long echoUs=1160,pulseTimeout=0;
Receiver IrReceiver;
#include "CompletedObstacleCar.ino"
using std::string;
struct Field {string key,actual,expected;};
int count=0,failed=0;
string n(long long x){return std::to_string(x);}
string f(float x){std::ostringstream s;s<<std::fixed<<std::setprecision(3)<<x;return s.str();}
string q(const string& x){string s="\"";for(char c:x){if(c=='\\'||c=='\"')s+='\\';if(c=='\n')s+="\\n";else s+=c;}return s+'\"';}
void emit(string group,string purpose,std::vector<string> inputs,std::vector<Field> fields){
 ++count;bool ok=true;for(auto& x:fields)ok&=x.actual==x.expected;if(!ok)++failed;
 std::cout<<"{\"id\":"<<q("IT-"+n(count))<<",\"function\":"<<q(group)<<",\"purpose\":"<<q(purpose)<<",\"inputs\":[";
 for(size_t i=0;i<inputs.size();i++)std::cout<<(i?",":"")<<q(inputs[i]);
 std::cout<<"],\"outputs\":[";
 for(size_t i=0;i<fields.size();i++){auto& x=fields[i];std::cout<<(i?",":"")<<"{\"key\":"<<q(x.key)<<",\"expected\":"<<q(x.expected)<<",\"actual\":"<<q(x.actual)<<"}";}
 std::cout<<"],\"result\":"<<q(ok?"合格（模擬）":"不合格（模擬）")<<"}\n";
}
void reset(){
 fakePulseAdvance=0;fakeNow=1000;for(int i=0;i<32;i++){pins[i]=LOW;pwm[i]=0;modes[i]=-1;}
 pins[0]=pins[2]=HIGH;pins[13]=HIGH;reads=writes=analogCalls=modeCalls=pulseCalls=delayCalls=0;
 pulsePin=pulseLevel=-1;pulseTimeout=0;echoUs=1160;IrReceiver=Receiver{};
 requested=STOP;holdActive=false;lastReceivedAt=1000;lastCommand=0;lastAddress=7;lastProtocol=NEC;
 appliedRight=appliedLeft=0;stopTimingActive=false;stoppedAt=0;
 SD=-1;SR1=SR2=IR=false;RM=M=0;distanceValid=false;sensorStarted=false;lastSensorAt=0;
 buzzerActive=false;buzzerStartedAt=0;
}
void active(Direction dir=FORWARD){requested=dir;holdActive=true;lastReceivedAt=fakeNow;lastCommand=IR_ADVANCE;}
void send(uint16_t command,uint8_t flags=0,uint16_t address=7,decode_type_t protocol=NEC){
 IrReceiver.pending=true;IrReceiver.decodedIRData.command=command;IrReceiver.decodedIRData.flags=flags;
 IrReceiver.decodedIRData.address=address;IrReceiver.decodedIRData.protocol=protocol;
}
int main(){
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"3"});
fields.push_back({"0ms:SR1",n(SR1),"0"});
fields.push_back({"0ms:SR2",n(SR2),"0"});
fields.push_back({"0ms:IR",n(IR),"0"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
fields.push_back({"0ms:left",n(appliedLeft),"180"});
emit("S-I-1","IT-001",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"1"});
fields.push_back({"0ms:SR1",n(SR1),"1"});
fields.push_back({"0ms:SR2",n(SR2),"0"});
fields.push_back({"0ms:right",n(appliedRight),"-100"});
fields.push_back({"0ms:left",n(appliedLeft),"-100"});
emit("S-I-1","IT-002",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=870; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"3"});
fields.push_back({"0ms:SR1",n(SR1),"0"});
fields.push_back({"0ms:SR2",n(SR2),"1"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
fields.push_back({"0ms:buzzer",n(pins[13]),"0"});
emit("S-I-1","IT-003",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=0; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:valid",n(distanceValid),"0"});
fields.push_back({"0ms:M",n(M),"0"});
fields.push_back({"0ms:right",n(appliedRight),"0"});
fields.push_back({"0ms:left",n(appliedLeft),"0"});
emit("S-I-1","IT-004",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1060; echoUs=580; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"60ms:M",n(M),"1"});
fields.push_back({"60ms:right",n(appliedRight),"0"});
fakeNow=1159; echoUs=580; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"159ms:right",n(appliedRight),"0"});
fakeNow=1160; echoUs=580; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"160ms:right",n(appliedRight),"-100"});
fields.push_back({"160ms:left",n(appliedLeft),"-100"});
emit("S-O-1","IT-005",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=581; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:SR1",n(SR1),"0"});
fields.push_back({"0ms:SR2",n(SR2),"1"});
fields.push_back({"0ms:M",n(M),"3"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
emit("S-O-1","IT-006",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=871; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:SR1",n(SR1),"0"});
fields.push_back({"0ms:SR2",n(SR2),"0"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
fields.push_back({"0ms:buzzer",n(pins[13]),"1"});
emit("S-O-1","IT-007",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1060; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"60ms:M",n(M),"3"});
fields.push_back({"60ms:right",n(appliedRight),"0"});
fakeNow=1160; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"160ms:right",n(appliedRight),"180"});
fields.push_back({"160ms:left",n(appliedLeft),"180"});
emit("S-O-1","IT-008",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(82,0,7,NEC);
loop();
fakeNow=1001; echoUs=1160; pins[0]=0; pins[2]=1;
send(82,1,7,NEC);
loop();
fields.push_back({"1ms:IR",n(IR),"1"});
fields.push_back({"1ms:M",n(M),"2"});
fields.push_back({"1ms:right",n(appliedRight),"0"});
fakeNow=1101; echoUs=1160; pins[0]=0; pins[2]=1;
send(82,1,7,NEC);
loop();
fields.push_back({"101ms:right",n(appliedRight),"100"});
fields.push_back({"101ms:left",n(appliedLeft),"100"});
emit("S-O-2","IT-009",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=0;
send(82,0,7,NEC);
loop();
fields.push_back({"0ms:IR",n(IR),"1"});
fields.push_back({"0ms:M",n(M),"2"});
fields.push_back({"0ms:right",n(appliedRight),"100"});
fields.push_back({"0ms:left",n(appliedLeft),"100"});
emit("S-O-2","IT-010",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=0; pins[2]=0;
send(82,0,7,NEC);
loop();
fields.push_back({"0ms:IR",n(IR),"1"});
fields.push_back({"0ms:M",n(M),"2"});
fields.push_back({"0ms:right",n(appliedRight),"100"});
fields.push_back({"0ms:left",n(appliedLeft),"100"});
emit("S-O-2","IT-011",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=0; pins[2]=1;
send(82,0,7,NEC);
loop();
fakeNow=1001; echoUs=1160; pins[0]=1; pins[2]=1;
send(82,1,7,NEC);
loop();
fields.push_back({"1ms:IR",n(IR),"0"});
fields.push_back({"1ms:M",n(M),"4"});
fields.push_back({"1ms:right",n(appliedRight),"0"});
fakeNow=1101; echoUs=1160; pins[0]=1; pins[2]=1;
send(82,1,7,NEC);
loop();
fields.push_back({"101ms:right",n(appliedRight),"-180"});
fields.push_back({"101ms:left",n(appliedLeft),"-180"});
emit("S-O-2","IT-012",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=870; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:buzzer",n(pins[13]),"0"});
fakeNow=1035; echoUs=870; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"35ms:buzzer",n(pins[13]),"1"});
fakeNow=1200; echoUs=870; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fakeNow=1400; echoUs=870; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fakeNow=1599; echoUs=870; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"599ms:buzzer",n(pins[13]),"1"});
fakeNow=1600; echoUs=870; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"600ms:buzzer",n(pins[13]),"0"});
emit("S-M-1","IT-013",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=725; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1200; echoUs=725; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fakeNow=1349; echoUs=725; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"349ms:buzzer",n(pins[13]),"1"});
fakeNow=1350; echoUs=725; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"350ms:buzzer",n(pins[13]),"0"});
emit("S-M-1","IT-014",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1034; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"34ms:buzzer",n(pins[13]),"0"});
fakeNow=1035; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"35ms:buzzer",n(pins[13]),"1"});
fakeNow=1099; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"99ms:buzzer",n(pins[13]),"1"});
fakeNow=1100; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"100ms:buzzer",n(pins[13]),"0"});
emit("S-M-1","IT-015",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"3"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
fields.push_back({"0ms:left",n(appliedLeft),"180"});
fields.push_back({"0ms:hold",n(holdActive),"1"});
emit("S-M-3","IT-016",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(82,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"4"});
fields.push_back({"0ms:right",n(appliedRight),"-180"});
fields.push_back({"0ms:left",n(appliedLeft),"-180"});
fields.push_back({"0ms:hold",n(holdActive),"1"});
emit("S-M-3","IT-017",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(90,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"5"});
fields.push_back({"0ms:right",n(appliedRight),"-180"});
fields.push_back({"0ms:left",n(appliedLeft),"180"});
fields.push_back({"0ms:hold",n(holdActive),"1"});
emit("S-M-3","IT-018",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(8,0,7,NEC);
loop();
fields.push_back({"0ms:M",n(M),"6"});
fields.push_back({"0ms:right",n(appliedRight),"180"});
fields.push_back({"0ms:left",n(appliedLeft),"-180"});
fields.push_back({"0ms:hold",n(holdActive),"1"});
emit("S-M-3","IT-019",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1200; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,1,7,NEC2);
loop();
fakeNow=1449; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"449ms:hold",n(holdActive),"1"});
fields.push_back({"449ms:right",n(appliedRight),"180"});
fields.push_back({"449ms:M",n(M),"3"});
emit("S-M-3","IT-020",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1249; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"249ms:right",n(appliedRight),"180"});
fakeNow=1250; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"250ms:hold",n(holdActive),"0"});
fields.push_back({"250ms:M",n(M),"0"});
fields.push_back({"250ms:right",n(appliedRight),"0"});
fields.push_back({"250ms:left",n(appliedLeft),"0"});
emit("S-M-3","IT-021",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1001; echoUs=580; pins[0]=1; pins[2]=1;
send(28,0,7,NEC);
loop();
fields.push_back({"1ms:hold",n(holdActive),"0"});
fields.push_back({"1ms:M",n(M),"0"});
fields.push_back({"1ms:right",n(appliedRight),"0"});
fields.push_back({"1ms:left",n(appliedLeft),"0"});
emit("S-M-2","IT-022",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1001; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,4,7,NEC);
loop();
fields.push_back({"1ms:hold",n(holdActive),"0"});
fields.push_back({"1ms:M",n(M),"0"});
fields.push_back({"1ms:right",n(appliedRight),"0"});
fields.push_back({"1ms:left",n(appliedLeft),"0"});
emit("S-M-2","IT-023",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=0; pins[2]=1;
send(24,0,7,NEC);
loop();
fields.push_back({"0ms:SR1",n(SR1),"1"});
fields.push_back({"0ms:IR",n(IR),"1"});
fields.push_back({"0ms:M",n(M),"0"});
fields.push_back({"0ms:right",n(appliedRight),"0"});
fields.push_back({"0ms:left",n(appliedLeft),"0"});
fields.push_back({"0ms:buzzer",n(pins[13]),"0"});
emit("S-M-2","IT-024",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1060; echoUs=0; pins[0]=1; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"60ms:valid",n(distanceValid),"0"});
fields.push_back({"60ms:M",n(M),"0"});
fields.push_back({"60ms:right",n(appliedRight),"0"});
fields.push_back({"60ms:left",n(appliedLeft),"0"});
emit("S-M-2","IT-025",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1200; echoUs=1160; pins[0]=1; pins[2]=1;
send(255,0,7,NEC);
loop();
fakeNow=1250; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"250ms:hold",n(holdActive),"0"});
fields.push_back({"250ms:M",n(M),"0"});
fields.push_back({"250ms:right",n(appliedRight),"0"});
emit("S-M-2","IT-026",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1200; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,1,8,NEC);
loop();
fakeNow=1250; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"250ms:hold",n(holdActive),"0"});
fields.push_back({"250ms:M",n(M),"0"});
fields.push_back({"250ms:right",n(appliedRight),"0"});
emit("S-M-2","IT-027",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1001; echoUs=1160; pins[0]=1; pins[2]=1;
send(82,0,7,NEC);
loop();
fields.push_back({"1ms:right",n(appliedRight),"0"});
fields.push_back({"1ms:left",n(appliedLeft),"0"});
fakeNow=1100; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"100ms:right",n(appliedRight),"0"});
fakeNow=1101; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"101ms:right",n(appliedRight),"-180"});
fields.push_back({"101ms:left",n(appliedLeft),"-180"});
emit("S-O-3","IT-028",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1001; echoUs=1160; pins[0]=1; pins[2]=1;
send(90,0,7,NEC);
loop();
fields.push_back({"1ms:right",n(appliedRight),"0"});
fields.push_back({"1ms:left",n(appliedLeft),"0"});
fakeNow=1101; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"101ms:right",n(appliedRight),"-180"});
fields.push_back({"101ms:left",n(appliedLeft),"180"});
emit("S-O-3","IT-029",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"0ms:hold",n(holdActive),"0"});
fields.push_back({"0ms:M",n(M),"0"});
fields.push_back({"0ms:right",n(appliedRight),"0"});
fields.push_back({"0ms:left",n(appliedLeft),"0"});
fields.push_back({"0ms:buzzer",n(pins[13]),"0"});
emit("S-O-3","IT-030",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=870; pins[0]=0; pins[2]=1;
send(82,0,7,NEC);
loop();
fields.push_back({"0ms:SR2",n(SR2),"1"});
fields.push_back({"0ms:M",n(M),"2"});
fields.push_back({"0ms:right",n(appliedRight),"100"});
fakeNow=1100; echoUs=870; pins[0]=0; pins[2]=1;
send(82,1,7,NEC);
loop();
fields.push_back({"100ms:buzzer",n(pins[13]),"0"});
emit("S-M-4","IT-031",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1001; echoUs=580; pins[0]=1; pins[2]=1;
send(28,0,7,NEC);
loop();
fakeNow=1100; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"100ms:M",n(M),"0"});
fields.push_back({"100ms:right",n(appliedRight),"0"});
fields.push_back({"100ms:buzzer",n(pins[13]),"0"});
fakeNow=1160; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"160ms:M",n(M),"0"});
fields.push_back({"160ms:right",n(appliedRight),"0"});
fields.push_back({"160ms:buzzer",n(pins[13]),"1"});
emit("S-M-4","IT-032",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1250; echoUs=580; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"250ms:hold",n(holdActive),"0"});
fields.push_back({"250ms:M",n(M),"0"});
fields.push_back({"250ms:right",n(appliedRight),"0"});
fields.push_back({"250ms:left",n(appliedLeft),"0"});
emit("S-M-4","IT-033",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(24,0,7,NEC);
loop();
fakeNow=1060; echoUs=1160; pins[0]=0; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"60ms:M",n(M),"2"});
fields.push_back({"60ms:right",n(appliedRight),"0"});
fakeNow=1160; echoUs=1160; pins[0]=0; pins[2]=1;
send(24,1,7,NEC);
loop();
fields.push_back({"160ms:M",n(M),"2"});
fields.push_back({"160ms:right",n(appliedRight),"100"});
fields.push_back({"160ms:left",n(appliedLeft),"100"});
emit("S-M-4","IT-034",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=580; pins[0]=1; pins[2]=1;
send(90,0,7,NEC);
loop();
fakeNow=1060; echoUs=1160; pins[0]=1; pins[2]=1;
send(90,1,7,NEC);
loop();
fields.push_back({"60ms:M",n(M),"5"});
fields.push_back({"60ms:right",n(appliedRight),"0"});
fields.push_back({"60ms:left",n(appliedLeft),"0"});
fakeNow=1160; echoUs=1160; pins[0]=1; pins[2]=1;
send(90,1,7,NEC);
loop();
fields.push_back({"160ms:right",n(appliedRight),"-180"});
fields.push_back({"160ms:left",n(appliedLeft),"180"});
emit("S-M-4","IT-035",{},fields); }
{ reset(); setup(); std::vector<Field> fields;
fakeNow=1000; echoUs=1160; pins[0]=1; pins[2]=1;
loop();
fields.push_back({"0ms:M",n(M),"0"});
fields.push_back({"0ms:hold",n(holdActive),"0"});
fields.push_back({"0ms:right",n(appliedRight),"0"});
fields.push_back({"0ms:left",n(appliedLeft),"0"});
fields.push_back({"0ms:buzzer",n(pins[13]),"1"});
fields.push_back({"0ms:receiverPin",n(IrReceiver.beginPin),"4"});
fields.push_back({"0ms:directionSum",n(pins[12]+pins[11]+pins[7]+pins[8]),"0"});
emit("S-M-4","IT-036",{},fields); }

 {reset();setup();send(24);loop();fakeNow=1059;echoUs=580;loop();std::vector<Field> fields={{"59ms:M",n(M),"3"},{"59ms:SR1",n(SR1),"0"},{"59ms:right",n(appliedRight),"180"}};fakeNow=1060;loop();fields.push_back({"60ms:M",n(M),"1"});fields.push_back({"60ms:right",n(appliedRight),"0"});emit("S-I-1","IT-037",{"Echo=20cm→10cm","経過59ms→60ms"},fields);}
 {reset();setup();send(24);loop();fakeNow=1200;send(24,IRDATA_FLAGS_IS_REPEAT,7,SONY);loop();fakeNow=1250;loop();emit("S-M-3","IT-038",{"NEC→SONYリピート","受信間隔250ms"},{{"holdActive",n(holdActive),"0"},{"M",n(M),"0"},{"right",n(appliedRight),"0"},{"left",n(appliedLeft),"0"}});}
 {reset();setup();echoUs=580;send(24);loop();fakeNow=1001;send(24,IRDATA_FLAGS_WAS_OVERFLOW);loop();emit("S-M-2","IT-039",{"前方10cm","受信overflow"},{{"holdActive",n(holdActive),"0"},{"M",n(M),"0"},{"right",n(appliedRight),"0"},{"left",n(appliedLeft),"0"}});}
 {reset();setup();send(24);loop();fakeNow=1245;fakePulseAdvance=10;loop();emit("S-M-4","IT-040",{"開始から245ms","pulseInで10ms経過","有効Echo=1160us"},{{"now",n(fakeNow),"1255"},{"distanceValid",n(distanceValid),"1"},{"holdActive",n(holdActive),"0"},{"M",n(M),"0"},{"right",n(appliedRight),"0"},{"left",n(appliedLeft),"0"}});}

std::cerr<<"TOTAL="<<count<<" FAILED="<<failed<<"\n";return failed?1:0; }